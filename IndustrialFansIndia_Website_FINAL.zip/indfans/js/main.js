/* ============================================================
   INDUSTRIAL FANS (INDIA) — Main JavaScript
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ── Header scroll behavior ── */
  const header = document.getElementById('main-header');
  const backTop = document.querySelector('.back-top');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 80) {
      header?.classList.add('scrolled');
      backTop?.classList.add('visible');
    } else {
      header?.classList.remove('scrolled');
      backTop?.classList.remove('visible');
    }
  }, { passive: true });

  backTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  /* ── Mobile nav ── */
  const hamburger = document.querySelector('.hamburger');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileClose = document.querySelector('.mobile-nav-close');

  hamburger?.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileNav?.classList.add('open');
    document.body.style.overflow = 'hidden';
  });

  const closeNav = () => {
    hamburger?.classList.remove('open');
    mobileNav?.classList.remove('open');
    document.body.style.overflow = '';
  };
  mobileClose?.addEventListener('click', closeNav);
  mobileNav?.addEventListener('click', (e) => { if (e.target === mobileNav) closeNav(); });

  /* ── Animated counters ── */
  const animateCounter = (el) => {
    const target = parseInt(el.dataset.target, 10);
    const suffix = el.dataset.suffix || '';
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const tick = () => {
      current = Math.min(current + step, target);
      el.textContent = Math.floor(current).toLocaleString() + suffix;
      if (current < target) requestAnimationFrame(tick);
    };
    tick();
  };

  const counters = document.querySelectorAll('[data-target]');
  if (counters.length) {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.dataset.done) {
          entry.target.dataset.done = '1';
          animateCounter(entry.target);
        }
      });
    }, { threshold: 0.3 });
    counters.forEach(c => obs.observe(c));
  }

  /* ── Scroll reveal ── */
  const fadeEls = document.querySelectorAll('.fade-up');
  if (fadeEls.length) {
    const revealObs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    fadeEls.forEach(el => revealObs.observe(el));
  }

  /* ── Contact form validation ── */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let valid = true;

      contactForm.querySelectorAll('[required]').forEach(field => {
        const err = field.parentElement.querySelector('.form-error');
        if (!field.value.trim()) {
          field.classList.add('error');
          if (err) { err.textContent = 'This field is required.'; err.classList.add('show'); }
          valid = false;
        } else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
          field.classList.add('error');
          if (err) { err.textContent = 'Please enter a valid email address.'; err.classList.add('show'); }
          valid = false;
        } else {
          field.classList.remove('error');
          if (err) err.classList.remove('show');
        }
      });

      if (valid) {
        const successMsg = document.getElementById('form-success');
        const submitBtn  = contactForm.querySelector('[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Sending…';
        }
        setTimeout(() => {
          contactForm.reset();
          if (successMsg) successMsg.classList.add('show');
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Send Inquiry'; }
        }, 1000);
      }
    });

    /* Clear errors on input */
    contactForm.querySelectorAll('input, select, textarea').forEach(field => {
      field.addEventListener('input', () => {
        field.classList.remove('error');
        const err = field.parentElement.querySelector('.form-error');
        if (err) err.classList.remove('show');
      });
    });
  }

  /* ── Product tabs ── */
  const tabs = document.querySelectorAll('.product-tab');
  const panes = document.querySelectorAll('.product-pane');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panes.forEach(p => p.hidden = true);
      tab.classList.add('active');
      const target = document.getElementById(tab.dataset.target);
      if (target) target.hidden = false;
    });
  });

  /* ── Smooth scroll for anchor links ── */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const offset = (header?.offsetHeight || 80) + 16;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
        closeNav();
      }
    });
  });

  /* ── Active nav link highlight ── */
  const navLinks = document.querySelectorAll('.nav-link');
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  navLinks.forEach(link => {
    const href = link.getAttribute('href') || '';
    if (href === currentPath || href.includes(currentPath)) {
      link.classList.add('active');
    }
  });

});
